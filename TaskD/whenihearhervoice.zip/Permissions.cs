internal enum Permissions
{
    Default,
    UserRead,
    UserWrite,
    UserExecute,
    GroupRead,
    GroupWrite,
    GroupExecute,
    EveryoneRead,
    EveryoneWrite,
    EveryoneExecute,
}