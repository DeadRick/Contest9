internal class Movie : Content
{

    public Movie(int size, string name, short duration, short releaseYear, string genre) : base(size, name)
    {

    }
}