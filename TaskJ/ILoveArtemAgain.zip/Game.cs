using System;

internal class Game : Content
{


    public Game(int size, string name, string developer, string genre, short levels) : base(size, name)
    {

    }
}