internal class Track : Content
{
    
   

    public Track(int size, string trackName, string singer, string albumName, short length) : base(size, trackName)
    {
       
    }
}