using System;

internal class Content
{
    public readonly int size;
    public readonly string information;
   


    public Content(int size, string information)
    {
        this.size = size;
        this.information = information; 
    }
}